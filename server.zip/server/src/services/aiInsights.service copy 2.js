import { callLLM } from "./aiClient.js";

// Robust parser that handles the pre-filled "{" and potential AI chatter
function safeParse(text) {
  try {
    // Ensure the text starts with a bracket
    const cleanText = text.startsWith('{') ? text : '{' + text;
    // Extract only the JSON block
    const jsonMatch = cleanText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON found");
    return JSON.parse(jsonMatch[0]);
  } catch (e) {
    // console.error("Parse Error. Raw text from AI:", text);
    return {
      summary: "Could not generate AI summary.",
      healthScore: 50,
      criticalIssues: [],
      recommendations: ["Manually review high-severity checks."]
    };
  }
}

// aiInsights.service.js

function compressReport(report) {
  // 1. Sort checks by severity as you did before
  const severityMap = { critical: 4, error: 3, warning: 2, info: 1 };
  const sorted = [...report.checks].sort((a, b) => 
    (severityMap[b.severity] || 0) - (severityMap[a.severity] || 0)
  );

  // 2. Return a richer context object
  return {
    // High-level metadata (The "Big Picture")
    metadata: {
      totalRows: report.totalRows || 0,
      duplicateRows: report.duplicateRows || 0,
      overallScore: report.overallScore || 0,
      tableCount: Object.keys(report.tables || {}).length
    },
    // Top issues (The "Specifics")
    topChecks: sorted.slice(0, 10), 
    regulationScores: report.regulationScores
  };
}

// async function generateAIInsights(report) {
//   const trimmed = compressReport(report);

//   // THE "FORCE-START" PROMPT:
//   // We end the prompt with "{" to force the model into JSON mode immediately.

// //   const prompt = `Instruct: You are a Data Quality Analyst.

// // STRICT RULES (follow ALL):
// // - Do NOT write code.
// // - Do NOT use markdown or backticks.
// // - Do NOT repeat any sentence or idea.
// // - Keep the response under 150 words.
// // - Do NOT include the input data in your answer.
// // - Stop writing after the Recommendations section.
// // - Be concise and direct.

// // Write a clean report using EXACTLY this format:

// // Summary:
// // (2 short sentences)

// // Health Score:
// // (number between 0-100, no explanation)

// // Critical Issues:
// // - Issue: ...
// //   Impact: ...
// //   Fix: ...

// // - Issue: ...
// //   Impact: ...
// //   Fix: ...

// // Recommendations:
// // - ...
// // - ...
// // - ...

// // Input:
// // ${JSON.stringify(trimmed)}

// // Answer:
// // `;

// const prompt = `Instruct: You are a Data Quality Analyst. 
// Return ONLY a JSON object. Do not include markdown, backticks, or intro text.

// Input: ${JSON.stringify(trimmed)}

// Target JSON Structure:
// {
//   "summary": "string",
//   "healthScore": number,
//   "criticalIssues": [{"issue": "string", "impact": "string", "fix": "string"}],
//   "recommendations": ["string"]
// }

// Answer: {`;

//   const raw = await callLLM(prompt);

//   console.log("This is the raw answer :");
//   console.log(raw);
//   return safeParse(raw);
// }

async function generateAIInsights(report) {
  const trimmed = compressReport(report);

  const prompt = `Instruct: You are a Data Quality Analyst.
Analyze the following data quality snapshot and provide a JSON report.

METADATA CONTEXT:
- Total Rows Scanned: ${trimmed.metadata.totalRows}
- Duplicate Rows: ${trimmed.metadata.duplicateRows}
- Overall Quality Score: ${trimmed.metadata.overallScore}%

TOP ISSUES FOUND:
${JSON.stringify(trimmed.topChecks)}

STRICT RULES:
- If duplicateRows > 0, prioritize mentioning it in the summary.
- Compare the "Top Issues" against the "Total Rows" to determine impact.
- Return ONLY a JSON object.

Answer: {`;

  const response = await callLLM(prompt);

  console.log(response);
  
  return safeParse(response);
}

export { generateAIInsights };