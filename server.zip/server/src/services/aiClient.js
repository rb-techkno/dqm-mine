import { setTimeout as delay } from "timers/promises";

async function callLLM(prompt) {
  const controller = new AbortController();

  // 🔥 Increase timeout (e.g., 10 minutes)
  const timeout = setTimeout(() => {
    controller.abort();
  }, 1000000); // 600000 ms = 10 min

  try {
    const res = await fetch("http://127.0.0.1:5001/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ prompt }),
      signal: controller.signal
    });

    const data = await res.json();
    return data.response;

  } catch (err) {
    console.error("LLM fetch error:", err);
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

export { callLLM };