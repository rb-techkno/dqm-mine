import { callLLM } from "./aiClient.js";

// function prepareAIInput(report) {
//   const checks = report.checks || [];

//   // ✅ Keep only real issues
//   const issues = checks.filter(c => c.isIssue === true);

//   // ✅ Remove noise rules
//   const ignoreRules = [
//     "Entropy Check",
//     "Data Drift Detection",
//     "Format Validation",
//     "Data Type Validation"
//   ];

//   const filtered = issues.filter(c => !ignoreRules.includes(c.ruleName));

//   // ✅ Group issues by rule
//   const grouped = {};

//   for (const c of filtered) {
//     if (!grouped[c.ruleName]) {
//       grouped[c.ruleName] = {
//         rule: c.ruleName,
//         severity: c.severity,
//         targets: [],
//         messages: []
//       };
//     }

//     grouped[c.ruleName].targets.push(c.target);
//     grouped[c.ruleName].messages.push(c.message);
//   }

//   return {
//     issues: Object.values(grouped),
//     totalIssues: filtered.length,
//     columnScores: report.columnScores || {},
//     regulationScores: report.regulationScores || []
//   };
// }

// function buildPrompt(aiInput) {
//   return `
// You are a Data Quality Analyst.

// STRICT RULES:
// - DO NOT invent issues
// - DO NOT ignore any issue
// - DO NOT change severity
// - DO NOT write code
// - Keep answer under 120 words

// Data:
// ${JSON.stringify(aiInput)}

// Write:

// Summary:
// (2 sentences)

// Health Score:
// (number between 0-100)

// Critical Issues:
// - Issue:
//   Impact:
//   Fix:

// Recommendations:
// - ...
// - ...
// `;
// }

function prepareAIInput(report) {
  const checks = report.checks || [];

  // 1. Keep only actual issues
  const issues = checks.filter(c => c.isIssue === true);

  // 2. DO NOT GROUP. Keep them flat so the AI sees every single one.
  // We sort them so Critical/Error issues are at the top.
  const severityMap = { critical: 4, error: 3, warning: 2, info: 1 };
  const sortedIssues = issues.sort((a, b) => severityMap[b.severity] - severityMap[a.severity]);

  return {
    engineHealthScore: report.healthScore, // Lock down the score
    totalIssues: issues.length,
    issues: sortedIssues.map(c => ({
      rule: c.ruleName,
      target: c.target, // Keeps specific columns/tables isolated
      severity: c.severity,
      message: c.message
    }))
  };
}

function buildPrompt(aiInput) {
  return `You are a Data Quality API. You only output valid JSON.

STRICT INSTRUCTIONS:
1. DO NOT group or combine issues. Keep them separated by "target".
2. DO NOT calculate the health score. Use the exact "engineHealthScore" provided.
3. You MUST include "Duplicate Row Detection", "ML Anomaly Detection", and "Primary Key Uniqueness" in your criticalIssues array if they exist in the data.

DATA FROM RULE ENGINE:
${JSON.stringify(aiInput)}

TARGET JSON FORMAT:
{
  "summary": "Brief 2-sentence summary of the data health.",
  "healthScore": ${aiInput.engineHealthScore}, 
  "criticalIssues": [
    {
      "issue": "[rule name]",
      "target": "[exact target from data]",
      "severity": "[critical/error/warning]",
      "impact": "[What is the business risk?]",
      "fix": "[How to resolve it?]"
    }
  ],
  "recommendations": ["High-level next steps"]
}

OUTPUT JSON:
{`;
}
export async function generateAIInsights(report) {
  const aiInput = prepareAIInput(report);
  console.log("THis is the ai input");
  console.log(aiInput);
  const prompt = buildPrompt(aiInput);
  console.log("THis is the prompt : " , prompt);
  console.log("Prompt length:", prompt.length);
  const raw = await callLLM(prompt);

  return raw; // return plain text
}