import { callLLM } from "./aiClient.js";

// Safe JSON parser
function safeParse(text) {
  try {
    return JSON.parse(text);
  } catch (e) {
    return {
      summary: "Failed to parse AI response",
      healthScore: null,
      criticalIssues: [],
      topRisks: [],
      complianceSummary: {},
      recommendations: []
    };
  }
}

// Reduce payload size (important)
function compressReport(report) {
  return {
    checks: report.checks.slice(0, 10), // limit
    regulationScores: report.regulationScores,
    columnScores: Object.fromEntries(
      Object.entries(report.columnScores).slice(0, 20)
    )
  };
}

// async function generateAIInsights(report) {
//   const trimmed = compressReport(report);

//   const prompt = `
// You are a senior data governance and compliance expert.

// Analyze the report below and return STRICT JSON:

// {
//   "summary": "short summary",
//   "healthScore": number (0-100),
//   "criticalIssues": [
//     { "issue": "...", "impact": "...", "fix": "..." }
//   ],
//   "topRisks": ["...", "...", "..."],
//   "complianceSummary": {
//     "GDPR": "...",
//     "HIPAA": "..."
//   },
//   "recommendations": ["...", "..."]
// }

// Rules:
// - Focus on CRITICAL and ERROR severity
// - Be concise
// - Do NOT hallucinate
// - Base ONLY on given data

// Report:
// ${JSON.stringify(trimmed)}
// `;
async function generateAIInsights(report) {
  const trimmed = compressReport(report);

  // Phi-2 specific formatting: Instruct -> Output
  const prompt = `Instruct: You are a data expert. Analyze this report and return ONLY a JSON object.
Do NOT repeat the input data. Do NOT provide a summary. Return ONLY valid JSON.

JSON Schema:
{
  "summary": "string",
  "healthScore": 0-100,
  "criticalIssues": [{"issue": "string", "impact": "string", "fix": "string"}],
  "recommendations": ["string"]
}

Report Data:
${JSON.stringify(trimmed)}

Output:`;
  const raw = await callLLM(prompt);

  console.log(raw);
  return safeParse(raw);
}

export { generateAIInsights };