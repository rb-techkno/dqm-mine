import { callLLM } from "./aiClient.js";
// aiInsights.service.js

function prepareAIInput(report) {
  const checks = report.checks || [];
  const issues = checks.filter(c => c.isIssue === true);

  // GROUPING: Prevents the AI from repeating itself by summarizing counts
  const summaryByCategory = issues.reduce((acc, c) => {
    if (!acc[c.ruleName]) acc[c.ruleName] = { count: 0, samples: [] };
    acc[c.ruleName].count++;
    if (acc[c.ruleName].samples.length < 3) acc[c.ruleName].samples.push(c.target);
    return acc;
  }, {});

  return {
    engineHealthScore: report.healthScore,
    totalIssues: issues.length,
    issueSummary: summaryByCategory, // Send grouped data
    rawIssues: issues.map(c => ({
      rule: c.ruleName,
      target: c.target,
      severity: c.severity,
      message: c.message
    }))
  };
}

function buildPrompt(aiInput) {
  return `You are a Data Quality API. Respond ONLY with valid JSON. No conversational text.

STRICT INSTRUCTIONS:
1. You MUST include these 4 categories in "criticalIssues" if they are in the data:
   - PII Detection
   - Duplicate Row Detection
   - Primary Key Uniqueness
   - Null Rate Check
2. Use "engineHealthScore" exactly: ${aiInput.engineHealthScore}

DATA:
${JSON.stringify(aiInput)}

TARGET JSON FORMAT:
{
  "summary": "2-sentence overview.",
  "healthScore": ${aiInput.engineHealthScore}, 
  "criticalIssues": [
    { "issue": "name", "target": "table/col", "severity": "crit/err/warn", "impact": "risk", "fix": "solution" }
  ],
  "recommendations": []
}

OUTPUT JSON:
{`;
}

export async function generateAIInsights(report) {
  const aiInput = prepareAIInput(report);
  const prompt = buildPrompt(aiInput);
  const raw = await callLLM(prompt);

  try {
    // 🛡️ THE FIX FOR DOUBLING: Extract only the content inside the first { and last }
    const jsonContent = raw.substring(raw.indexOf("{"), raw.lastIndexOf("}") + 1) || ("{" + raw);
    return JSON.parse(jsonContent); 
  } catch (err) {
    console.error("AI Parse Error. Raw was:", raw);
    return { summary: "Error parsing AI response.", healthScore: aiInput.engineHealthScore, criticalIssues: [], recommendations: [] };
  }
}